// TODO(CodelabUser): Create an OAuth App
const githubClientId = 'Ov23liSNHNwW5P3nFXHP';
const githubClientSecret = '0615aa1416d79ec906aeaef8cb9f192f79294363';

// OAuth scopes for repository and user information
const githubScopes = ['repo', 'read:org'];