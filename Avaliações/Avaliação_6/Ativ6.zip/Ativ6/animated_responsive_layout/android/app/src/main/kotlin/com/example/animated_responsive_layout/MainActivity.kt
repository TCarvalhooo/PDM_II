package com.example.animated_responsive_layout

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
